'use client'
import { useState, useEffect, useCallback } from 'react'
import { ApplicationFull, FIT_COLORS, FIT_TEXT, LEVEL_COLORS, LEVEL_TEXT } from '@/types'

const CAREER_EMAIL = 'careers@palmbeachstate.edu'
const CAREER_PHONE = '(561) 868-3000'

export default function AdvisorPage() {
  const [authed, setAuthed]         = useState(false)
  const [password, setPassword]     = useState('')
  const [authError, setAuthError]   = useState('')
  const [apps, setApps]             = useState<ApplicationFull[]>([])
  const [loading, setLoading]       = useState(false)
  const [tab, setTab]               = useState<'notifications'|'outreach'>('notifications')
  const [composing, setComposing]   = useState<string|null>(null)
  const [emailBodies, setEmailBodies] = useState<Record<string,string>>({})
  const [sentEmails, setSentEmails]   = useState<Set<string>>(new Set())
  const [sending, setSending]         = useState<string|null>(null)
  const [actionStates, setActionStates] = useState<Record<string,Record<string,boolean>>>({})

  function buildEmailBody(a: ApplicationFull) {
    return `Dear ${a.job_employer} Hiring Team,

I'm reaching out on behalf of Palm Beach State College Career Services to introduce ${a.student_name}, a student in our ${a.student_program} program (graduating ${a.student_graduation}), who has just applied for your ${a.job_title} position.

${a.student_name} has been developing the skills for this role through PBSC's accredited curriculum, and based on our program-to-market alignment analysis, this is a strong match for their academic training and career track.

PBSC graduates are locally based, work-ready, and supported through our Career Services office. We would be happy to share additional information about our programs or provide a student profile upon request.

We appreciate your consideration and look forward to a continued partnership with your organization.

Warm regards,
PBSC Career Services
${CAREER_EMAIL} | ${CAREER_PHONE}
Palm Beach State College, Lake Worth, FL`
  }

  const fetchApps = useCallback(async (pw: string) => {
    setLoading(true)
    const res = await fetch('/api/applications', {
      headers: { 'x-advisor-password': pw }
    })
    if (!res.ok) { setLoading(false); return }
    const data = await res.json()
    const list: ApplicationFull[] = data.applications || []
    setApps(list)
    const bodies: Record<string,string> = {}
    list.forEach(a => { bodies[a.id] = buildEmailBody(a) })
    setEmailBodies(bodies)
    setLoading(false)
  }, [])

  async function login(e: React.FormEvent) {
    e.preventDefault()
    const res = await fetch('/api/applications', {
      headers: { 'x-advisor-password': password }
    })
    if (res.ok) {
      setAuthed(true)
      const data = await res.json()
      const list: ApplicationFull[] = data.applications || []
      setApps(list)
      const bodies: Record<string,string> = {}
      list.forEach(a => { bodies[a.id] = buildEmailBody(a) })
      setEmailBodies(bodies)
    } else {
      setAuthError('Incorrect password. Contact IT for access.')
    }
  }

  // Poll for new applications every 30s
  useEffect(() => {
    if (!authed) return
    const interval = setInterval(() => fetchApps(password), 30000)
    return () => clearInterval(interval)
  }, [authed, password, fetchApps])

  async function toggleAction(appId: string, field: string, value: boolean) {
    setActionStates(s => ({ ...s, [appId]: { ...(s[appId]||{}), [field]: value } }))
    await fetch(`/api/applications/${appId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-advisor-password': password },
      body: JSON.stringify({ [field]: value }),
    })
  }

  async function sendOutreach(a: ApplicationFull) {
    if (!a.employer_email) { alert('No employer email on file for this listing.'); return }
    setSending(a.id)
    const res = await fetch('/api/outreach', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-advisor-password': password },
      body: JSON.stringify({
        applicationId: a.id,
        employerEmail: a.employer_email,
        employerName:  a.job_employer,
        studentName:   a.student_name,
        program:       a.student_program,
        graduation:    a.student_graduation,
        jobTitle:      a.job_title,
        customBody:    emailBodies[a.id] || buildEmailBody(a),
        sentBy:        'Career Services Advisor',
      }),
    })
    setSending(null)
    if (res.ok) setSentEmails(s => new Set([...s, a.id]))
    else alert('Email failed. Check SendGrid configuration.')
  }

  const pill = (label: string, bg: string, fg: string) => (
    <span style={{ background: bg, color: fg, fontSize: 10, fontWeight: 600, padding: '2px 7px', borderRadius: 5 }}>{label}</span>
  )

  if (!authed) return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
      <div style={{ background: '#fff', borderRadius: 12, border: '1px solid #e0e0e0', padding: 28, width: '100%', maxWidth: 360 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 20 }}>
          <div style={{ width: 36, height: 36, borderRadius: 8, background: '#0C447C', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>
          </div>
          <div>
            <div style={{ fontSize: 14, fontWeight: 600 }}>PBSC Career Services</div>
            <div style={{ fontSize: 11, color: '#888' }}>Advisor access</div>
          </div>
        </div>
        <form onSubmit={login}>
          <label style={{ fontSize: 12, color: '#666', display: 'block', marginBottom: 4 }}>Advisor password</label>
          <input type="password" value={password} onChange={e => setPassword(e.target.value)}
            placeholder="Enter advisor password" autoFocus
            style={{ width: '100%', fontSize: 13, padding: '9px 10px', border: '1px solid #ccc', borderRadius: 6, marginBottom: 12 }} />
          {authError && <div style={{ color: '#A32D2D', fontSize: 12, marginBottom: 10 }}>{authError}</div>}
          <button type="submit" style={{ width: '100%', background: '#0C447C', color: '#fff', border: 'none', borderRadius: 8, padding: 10, fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>
            Sign in →
          </button>
        </form>
        <div style={{ marginTop: 14, textAlign: 'center' }}>
          <a href="/student" style={{ fontSize: 12, color: '#888', textDecoration: 'none' }}>← Student job board</a>
        </div>
      </div>
    </div>
  )

  const pending  = apps.filter(a => !a.followup_flagged).length
  const thisWeek = apps.filter(a => {
    const d = new Date(a.applied_at)
    const now = new Date()
    return (now.getTime() - d.getTime()) < 7 * 24 * 60 * 60 * 1000
  }).length

  return (
    <div>
      <div style={{ background: '#0C447C', padding: '14px 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, color: '#fff', fontSize: 15, fontWeight: 600 }}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>
          PBSC Career Services — Advisor Dashboard
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <a href="/student" style={{ fontSize: 11, background: 'rgba(255,255,255,.18)', color: '#fff', padding: '3px 9px', borderRadius: 6, textDecoration: 'none' }}>Student board</a>
          <a href="/admin"   style={{ fontSize: 11, background: 'rgba(255,255,255,.18)', color: '#fff', padding: '3px 9px', borderRadius: 6, textDecoration: 'none' }}>Admin →</a>
        </div>
      </div>

      <div style={{ padding: 24, maxWidth: 900, margin: '0 auto' }}>
        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12, marginBottom: 20 }}>
          {[[String(apps.length),'Total applications'],[String(thisWeek),'This week'],[String(pending),'Pending follow-up']].map(([n,l]) => (
            <div key={l} style={{ background: '#f0f0ee', borderRadius: 8, padding: '14px 16px' }}>
              <div style={{ fontSize: 26, fontWeight: 600 }}>{n}</div>
              <div style={{ fontSize: 12, color: '#888', marginTop: 2 }}>{l}</div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div style={{ display: 'flex', gap: 0, borderBottom: '1px solid #e0e0e0', marginBottom: 20, background: '#fff', borderRadius: '8px 8px 0 0' }}>
          {(['notifications','outreach'] as const).map(t => (
            <button key={t} onClick={() => setTab(t)}
              style={{ padding: '10px 20px', fontSize: 13, fontWeight: 500, border: 'none', background: 'none', cursor: 'pointer',
                       color: tab===t ? '#0C447C' : '#888', borderBottom: tab===t ? '2px solid #0C447C' : '2px solid transparent', marginBottom: -1 }}>
              {t === 'notifications' ? `Application alerts (${apps.length})` : `Employer outreach (${apps.length})`}
            </button>
          ))}
          <button onClick={() => fetchApps(password)} style={{ marginLeft: 'auto', fontSize: 11, color: '#888', border: 'none', background: 'none', cursor: 'pointer', padding: '10px 16px' }}>
            ↻ Refresh
          </button>
        </div>

        {loading && <div style={{ textAlign: 'center', padding: 40, color: '#888' }}>Loading...</div>}

        {!loading && apps.length === 0 && (
          <div style={{ textAlign: 'center', padding: 40, color: '#aaa', border: '1px solid #e0e0e0', borderRadius: 10 }}>
            No applications yet — they appear here in real time when students apply via the job board.
          </div>
        )}

        {!loading && tab === 'notifications' && apps.map(a => {
          const actions = actionStates[a.id] || {}
          return (
            <div key={a.id} style={{ background: '#fff', border: '1px solid #e0e0e0', borderRadius: 10, marginBottom: 12, overflow: 'hidden' }}>
              <div style={{ background: '#0C447C', padding: '10px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: 12, fontWeight: 600, color: '#fff' }}>
                  <span style={{ display: 'inline-block', width: 8, height: 8, borderRadius: '50%', background: '#1D9E75', marginRight: 8 }}></span>
                  New application — {a.job_title}
                </span>
                <time style={{ fontSize: 11, color: '#B5D4F4' }}>{new Date(a.applied_at).toLocaleString()}</time>
              </div>
              <div style={{ padding: 16 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
                  <div style={{ width: 42, height: 42, borderRadius: '50%', background: '#E6F1FB', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 600, color: '#0C447C', flexShrink: 0 }}>
                    {a.student_name.split(' ').map((w:string) => w[0]).join('').slice(0,2).toUpperCase()}
                  </div>
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 600 }}>{a.student_name}</div>
                    <div style={{ fontSize: 12, color: '#666' }}>ID: {a.student_pbsc_id}{a.student_email && ` · ${a.student_email}`}</div>
                  </div>
                  <div style={{ marginLeft: 'auto' }}>{pill(a.job_level, LEVEL_COLORS[a.job_level]||'#eee', LEVEL_TEXT[a.job_level]||'#333')}</div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '130px 1fr', gap: 7, fontSize: 12, marginBottom: 14 }}>
                  {[['Program',a.student_program],['Graduating',a.student_graduation],['Applied to',a.job_title],['Employer',a.job_employer]].map(([l,v]) => (
                    <><span style={{ color: '#888' }}>{l}</span><span style={{ color: '#1a1a1a' }}>{v}</span></>
                  ))}
                  <span style={{ color: '#888' }}>Alignment</span>
                  <span>{pill(`${a.job_fit} fit`, FIT_COLORS[a.job_fit]||'#eee', FIT_TEXT[a.job_fit]||'#333')}</span>
                </div>

                <div style={{ fontSize: 11, color: '#888', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.04em', marginBottom: 8 }}>Suggested actions</div>
                <div style={{ display: 'grid', gap: 6, marginBottom: 4 }}>
                  {[
                    { label: `Send ${a.student_name.split(' ')[0]} resume review resources`, field: 'resume_sent' },
                    { label: 'Schedule 15-min advising check-in', field: 'checkin_scheduled' },
                    { label: 'Flag for 2-week outcome follow-up', field: 'followup_flagged' },
                  ].map(({ label, field }) => {
                    const done = actions[field] ?? (a as any)[field]
                    return (
                      <button key={field} onClick={() => toggleAction(a.id, field, !done)}
                        style={{ textAlign: 'left', background: done ? '#f0f0ee' : '#f5f5f3', border: '1px solid #ddd', borderRadius: 6, padding: '8px 12px', fontSize: 12, color: done ? '#aaa' : '#1a1a1a', cursor: 'pointer', textDecoration: done ? 'line-through' : 'none' }}>
                        {done ? '✓ ' : ''}{label}
                      </button>
                    )
                  })}
                </div>
              </div>
            </div>
          )
        })}

        {!loading && tab === 'outreach' && apps.map(a => (
          <div key={a.id} style={{ background: '#fff', border: '1px solid #e0e0e0', borderRadius: 10, marginBottom: 12, overflow: 'hidden' }}>
            <div style={{ padding: '13px 16px', borderBottom: '1px solid #e0e0e0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600 }}>{a.job_employer}</div>
                <div style={{ fontSize: 12, color: '#666' }}>{a.job_title} · {a.employer_email || 'No email on file'}</div>
              </div>
              {pill(`${a.job_fit} fit`, FIT_COLORS[a.job_fit]||'#eee', FIT_TEXT[a.job_fit]||'#333')}
            </div>
            <div style={{ padding: 16 }}>
              <p style={{ fontSize: 12, color: '#666', marginBottom: 12, lineHeight: 1.7 }}>
                <strong style={{ color: '#1a1a1a' }}>{a.student_name}</strong> ({a.student_program}, graduating {a.student_graduation}) applied for <strong style={{ color: '#1a1a1a' }}>{a.job_title}</strong>.
                {sentEmails.has(a.id) && <span style={{ color: '#27500A', fontWeight: 600 }}> ✓ Introduction sent.</span>}
              </p>

              {composing === a.id ? (
                <div style={{ background: '#f5f5f3', borderRadius: 8, padding: 12 }}>
                  <label style={{ fontSize: 11, color: '#888', display: 'block', marginBottom: 5 }}>
                    Email to {a.employer_email || '(no email on file)'} — edit before sending
                  </label>
                  <textarea rows={10} value={emailBodies[a.id] || ''}
                    onChange={e => setEmailBodies(b => ({ ...b, [a.id]: e.target.value }))}
                    style={{ width: '100%', fontSize: 12, border: '1px solid #ccc', borderRadius: 6, padding: 8, background: '#fff', resize: 'vertical', lineHeight: 1.6 }} />
                  <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
                    <button onClick={() => sendOutreach(a)} disabled={!!sending || sentEmails.has(a.id)}
                      style={{ background: sentEmails.has(a.id) ? '#888' : '#27500A', color: '#fff', border: 'none', borderRadius: 6, padding: '8px 16px', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>
                      {sending === a.id ? 'Sending...' : sentEmails.has(a.id) ? '✓ Sent' : 'Send introduction email'}
                    </button>
                    <button onClick={() => setComposing(null)} style={{ background: 'none', border: '1px solid #ccc', borderRadius: 6, padding: '8px 12px', fontSize: 12, cursor: 'pointer', color: '#666' }}>
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <button onClick={() => { setComposing(a.id); if (!emailBodies[a.id]) setEmailBodies(b => ({ ...b, [a.id]: buildEmailBody(a) })) }}
                  style={{ background: sentEmails.has(a.id) ? '#f5f5f3' : '#27500A', color: sentEmails.has(a.id) ? '#888' : '#fff', border: 'none', borderRadius: 6, padding: '8px 16px', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>
                  {sentEmails.has(a.id) ? '✓ Email sent — compose another' : 'Compose & send employer introduction'}
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
