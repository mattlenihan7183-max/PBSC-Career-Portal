'use client'
import { useState, useEffect, useCallback } from 'react'
import { Job, PROGRAMS, GRADUATIONS, FIT_COLORS, FIT_TEXT, LEVEL_COLORS, LEVEL_TEXT } from '@/types'

const SRC_LABELS: Record<string, string> = { I: 'Indeed/LI', B: 'BDB', P: 'Intern PB', 'B+P': 'BDB+IPB' }
const SRC_BG: Record<string, string>     = { I: '#E6F1FB', B: '#EAF3DE', P: '#FAEEDA', 'B+P': '#EEEDFE' }
const SRC_FG: Record<string, string>     = { I: '#0C447C', B: '#27500A', P: '#633806', 'B+P': '#3C3489' }

export default function StudentPage() {
  const [jobs, setJobs]           = useState<Job[]>([])
  const [loading, setLoading]     = useState(true)
  const [search, setSearch]       = useState('')
  const [level, setLevel]         = useState('')
  const [category, setCategory]   = useState('')
  const [program, setProgram]     = useState('')
  const [selected, setSelected]   = useState<Job | null>(null)
  const [step, setStep]           = useState<'form' | 'success'>('form')
  const [submitting, setSubmitting] = useState(false)
  const [error, setError]         = useState('')
  const [form, setForm] = useState({
    name: '', studentId: '', email: '', program: PROGRAMS[0].value, graduation: GRADUATIONS[0], consent: true
  })

  const fetchJobs = useCallback(async () => {
    setLoading(true)
    const params = new URLSearchParams()
    if (level)    params.set('level', level)
    if (category) params.set('category', category)
    if (program)  params.set('program', program)
    if (search)   params.set('search', search)
    const res  = await fetch(`/api/jobs?${params}`)
    const data = await res.json()
    setJobs(data.jobs || [])
    setLoading(false)
  }, [level, category, program, search])

  useEffect(() => {
    const t = setTimeout(fetchJobs, 300)
    return () => clearTimeout(t)
  }, [fetchJobs])

  async function handleApply(e: React.FormEvent) {
    e.preventDefault()
    if (!form.name || !form.studentId) { setError('Name and Student ID are required.'); return }
    setSubmitting(true); setError('')
    const res = await fetch('/api/applications', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...form, jobId: selected?.id }),
    })
    const data = await res.json()
    setSubmitting(false)
    if (!res.ok) { setError(data.error || 'Something went wrong.'); return }
    setStep('success')
  }

  const pill = (label: string, bg: string, fg: string) => (
    <span style={{ background: bg, color: fg, fontSize: 10, fontWeight: 600, padding: '2px 7px', borderRadius: 5, display: 'inline-block' }}>{label}</span>
  )

  return (
    <div>
      {/* Top bar */}
      <div style={{ background: '#0C447C', padding: '14px 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, color: '#fff', fontSize: 15, fontWeight: 600 }}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>
          PBSC Career Services
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <span style={{ fontSize: 11, background: 'rgba(255,255,255,.18)', color: '#fff', padding: '3px 9px', borderRadius: 6 }}>Student portal</span>
          <a href="/advisor" style={{ fontSize: 11, background: 'rgba(255,255,255,.18)', color: '#fff', padding: '3px 9px', borderRadius: 6, textDecoration: 'none' }}>Advisor view →</a>
        </div>
      </div>

      <div style={{ padding: '24px', maxWidth: 900, margin: '0 auto' }}>
        <h1 className="sr-only">PBSC Job Board — Palm Beach County opportunities for students</h1>

        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 20 }}>
          {[['52','Active listings'],['21','Internships'],['10','Entry-level roles'],['3','Job board sources']].map(([n,l]) => (
            <div key={l} style={{ background: '#f0f0ee', borderRadius: 8, padding: '14px 16px' }}>
              <div style={{ fontSize: 26, fontWeight: 600 }}>{n}</div>
              <div style={{ fontSize: 12, color: '#888', marginTop: 2 }}>{l}</div>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 16, flexWrap: 'wrap' }}>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search jobs or employers..."
            style={{ flex: 1, minWidth: 180, fontSize: 13, padding: '8px 10px', border: '1px solid #ccc', borderRadius: 6 }} />
          {[
            { value: level,    setter: setLevel,    opts: [['','All levels'],['Entry','Entry'],['Mid','Mid'],['Intern','Intern']] },
            { value: category, setter: setCategory, opts: [['','All categories'],['IT','IT & Technology'],['Business','Business'],['Data','Data & Analytics'],['Finance','Finance']] },
          ].map(({ value, setter, opts }, i) => (
            <select key={i} value={value} onChange={e => setter(e.target.value)}
              style={{ fontSize: 13, padding: '8px 10px', border: '1px solid #ccc', borderRadius: 6, background: '#fff' }}>
              {opts.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
          ))}
          <select value={program} onChange={e => setProgram(e.target.value)}
            style={{ fontSize: 13, padding: '8px 10px', border: '1px solid #ccc', borderRadius: 6, background: '#fff' }}>
            <option value="">All programs</option>
            {PROGRAMS.map(p => <option key={p.value} value={p.value}>{p.label}</option>)}
          </select>
        </div>

        {/* Job list */}
        {loading ? (
          <div style={{ textAlign: 'center', padding: 40, color: '#888' }}>Loading listings...</div>
        ) : jobs.length === 0 ? (
          <div style={{ textAlign: 'center', padding: 40, color: '#aaa', border: '1px solid #e0e0e0', borderRadius: 10 }}>No listings match your filters.</div>
        ) : jobs.map(j => (
          <div key={j.id} onClick={() => { setSelected(j); setStep('form'); setError('') }}
            style={{ background: '#fff', border: '1px solid #e0e0e0', borderRadius: 10, padding: '14px 16px', marginBottom: 10, cursor: 'pointer', transition: 'border-color .15s' }}
            onMouseEnter={e => (e.currentTarget.style.borderColor = '#0C447C')}
            onMouseLeave={e => (e.currentTarget.style.borderColor = '#e0e0e0')}>
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 10, marginBottom: 8 }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600 }}>{j.title}</div>
                <div style={{ fontSize: 12, color: '#666', marginTop: 2 }}>{j.employer}</div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 4, alignItems: 'flex-end', flexShrink: 0 }}>
                {pill(j.level, LEVEL_COLORS[j.level], LEVEL_TEXT[j.level])}
                {pill(`${j.fit} fit`, FIT_COLORS[j.fit], FIT_TEXT[j.fit])}
              </div>
            </div>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', alignItems: 'center' }}>
              {pill(SRC_LABELS[j.source] || j.source, SRC_BG[j.source] || '#eee', SRC_FG[j.source] || '#333')}
              <span style={{ fontSize: 11, color: '#999' }}>{j.skills}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Apply modal */}
      {selected && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.45)', zIndex: 100, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}
          onClick={e => { if (e.target === e.currentTarget) setSelected(null) }}>
          <div style={{ background: '#fff', borderRadius: 12, padding: 24, width: '100%', maxWidth: 460, maxHeight: '90vh', overflowY: 'auto' }}>
            {step === 'form' ? (
              <form onSubmit={handleApply}>
                <h3 style={{ fontSize: 16, fontWeight: 600, marginBottom: 4 }}>Almost there</h3>
                <p style={{ fontSize: 13, color: '#666', marginBottom: 16 }}>Help your advisor support your application — takes 20 seconds.</p>

                <div style={{ background: '#E6F1FB', borderRadius: 8, padding: '12px 14px', marginBottom: 16 }}>
                  <div style={{ fontSize: 11, color: '#0C447C', fontWeight: 600, marginBottom: 3 }}>Applying to</div>
                  <div style={{ fontSize: 15, fontWeight: 600 }}>{selected.title}</div>
                  <div style={{ fontSize: 12, color: '#555', marginTop: 2 }}>{selected.employer}</div>
                </div>

                {[
                  { label: 'Full name *', key: 'name', type: 'text', placeholder: 'Maria Gonzalez' },
                  { label: 'Student ID *', key: 'studentId', type: 'text', placeholder: 'PB-2024-00847' },
                  { label: 'Email (optional)', key: 'email', type: 'email', placeholder: 'you@student.palmbeachstate.edu' },
                ].map(({ label, key, type, placeholder }) => (
                  <div key={key} style={{ marginBottom: 12 }}>
                    <label style={{ fontSize: 12, color: '#666', display: 'block', marginBottom: 4 }}>{label}</label>
                    <input type={type} placeholder={placeholder} value={(form as any)[key]}
                      onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
                      style={{ width: '100%', fontSize: 13, padding: '8px 10px', border: '1px solid #ccc', borderRadius: 6 }} />
                  </div>
                ))}

                <div style={{ marginBottom: 12 }}>
                  <label style={{ fontSize: 12, color: '#666', display: 'block', marginBottom: 4 }}>Your PBSC program *</label>
                  <select value={form.program} onChange={e => setForm(f => ({ ...f, program: e.target.value }))}
                    style={{ width: '100%', fontSize: 13, padding: '8px 10px', border: '1px solid #ccc', borderRadius: 6 }}>
                    {PROGRAMS.map(p => <option key={p.value} value={p.value}>{p.label}</option>)}
                  </select>
                </div>

                <div style={{ marginBottom: 12 }}>
                  <label style={{ fontSize: 12, color: '#666', display: 'block', marginBottom: 4 }}>Expected graduation *</label>
                  <select value={form.graduation} onChange={e => setForm(f => ({ ...f, graduation: e.target.value }))}
                    style={{ width: '100%', fontSize: 13, padding: '8px 10px', border: '1px solid #ccc', borderRadius: 6 }}>
                    {GRADUATIONS.map(g => <option key={g} value={g}>{g}</option>)}
                  </select>
                </div>

                <div style={{ background: '#f5f5f3', borderRadius: 6, padding: '10px 12px', display: 'flex', gap: 10, alignItems: 'flex-start', marginBottom: 16 }}>
                  <input type="checkbox" checked={form.consent} onChange={e => setForm(f => ({ ...f, consent: e.target.checked }))} style={{ marginTop: 2, flexShrink: 0 }} />
                  <span style={{ fontSize: 11, color: '#666', lineHeight: 1.6 }}>I understand PBSC Career Services will log this application and may follow up with advising support. My information will not be shared with the employer without my permission.</span>
                </div>

                {error && <div style={{ color: '#A32D2D', fontSize: 12, marginBottom: 10 }}>{error}</div>}

                <button type="submit" disabled={submitting || !form.consent}
                  style={{ width: '100%', background: submitting ? '#ccc' : '#0C447C', color: '#fff', border: 'none', borderRadius: 8, padding: 11, fontSize: 13, fontWeight: 600, cursor: submitting ? 'default' : 'pointer', marginBottom: 8 }}>
                  {submitting ? 'Submitting...' : 'Continue to application →'}
                </button>
                <button type="button" onClick={() => setSelected(null)}
                  style={{ width: '100%', background: 'none', border: 'none', fontSize: 11, color: '#aaa', cursor: 'pointer' }}>
                  Skip and go directly to listing
                </button>
              </form>
            ) : (
              <div>
                <div style={{ background: '#E1F5EE', border: '1px solid #9FE1CB', borderRadius: 10, padding: 16, textAlign: 'center', marginBottom: 14 }}>
                  <div style={{ width: 40, height: 40, borderRadius: '50%', background: '#1D9E75', margin: '0 auto 10px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                  </div>
                  <div style={{ fontSize: 15, fontWeight: 600, color: '#085041', marginBottom: 4 }}>You're on your way, {form.name.split(' ')[0]}!</div>
                  <div style={{ fontSize: 12, color: '#0F6E56' }}>Your advisor has been notified and will reach out.</div>
                </div>
                <div style={{ background: '#f5f5f3', borderRadius: 8, padding: '12px 14px', marginBottom: 16, fontSize: 12, color: '#666', lineHeight: 1.7 }}>
                  <strong style={{ color: '#1a1a1a' }}>What happens next</strong><br />
                  Your advisor will review your application and may reach out with resume tips or interview prep. In two weeks you'll receive a short follow-up asking if you heard back.
                </div>
                <a href={selected.apply_url} target="_blank" rel="noopener noreferrer"
                  style={{ display: 'block', width: '100%', background: '#0C447C', color: '#fff', border: 'none', borderRadius: 8, padding: 11, fontSize: 13, fontWeight: 600, textAlign: 'center', textDecoration: 'none', marginBottom: 8 }}>
                  Go to job listing →
                </a>
                <button onClick={() => setSelected(null)}
                  style={{ width: '100%', background: 'none', border: 'none', fontSize: 11, color: '#aaa', cursor: 'pointer' }}>
                  Back to job board
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
