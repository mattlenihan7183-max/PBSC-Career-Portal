'use client'
import { useState, useEffect } from 'react'
import { Job, PROGRAMS } from '@/types'

const BLANK: Partial<Job> = {
  title:'', employer:'', employer_email:'', category:'IT', level:'Entry',
  source:'I', apply_url:'', fit:'Strong', skills:'', programs:[], is_active:true
}

export default function AdminPage() {
  const [authed, setAuthed]   = useState(false)
  const [password, setPassword] = useState('')
  const [authError, setAuthError] = useState('')
  const [jobs, setJobs]       = useState<Job[]>([])
  const [loading, setLoading] = useState(false)
  const [form, setForm]       = useState<Partial<Job>>(BLANK)
  const [saving, setSaving]   = useState(false)
  const [saved, setSaved]     = useState(false)
  const [error, setError]     = useState('')

  async function login(e: React.FormEvent) {
    e.preventDefault()
    const res = await fetch('/api/jobs', { headers: { 'x-admin-password': password } })
    if (res.ok) { setAuthed(true); loadJobs(password) }
    else setAuthError('Incorrect admin password.')
  }

  async function loadJobs(pw: string) {
    setLoading(true)
    const res = await fetch('/api/jobs?all=true', { headers: { 'x-admin-password': pw } })
    const data = await res.json()
    setJobs(data.jobs || [])
    setLoading(false)
  }

  async function addJob(e: React.FormEvent) {
    e.preventDefault()
    setSaving(true); setError('')
    const res = await fetch('/api/jobs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify(form),
    })
    const data = await res.json()
    setSaving(false)
    if (!res.ok) { setError(data.error || 'Failed to save'); return }
    setJobs(j => [data.job, ...j])
    setForm(BLANK)
    setSaved(true)
    setTimeout(() => setSaved(false), 3000)
  }

  if (!authed) return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
      <div style={{ background: '#fff', borderRadius: 12, border: '1px solid #e0e0e0', padding: 28, width: '100%', maxWidth: 360 }}>
        <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 4 }}>Admin — Job Management</div>
        <div style={{ fontSize: 12, color: '#888', marginBottom: 20 }}>PBSC Career Services</div>
        <form onSubmit={login}>
          <input type="password" value={password} onChange={e => setPassword(e.target.value)}
            placeholder="Admin password" autoFocus
            style={{ width: '100%', fontSize: 13, padding: '9px 10px', border: '1px solid #ccc', borderRadius: 6, marginBottom: 12 }} />
          {authError && <div style={{ color: '#A32D2D', fontSize: 12, marginBottom: 10 }}>{authError}</div>}
          <button type="submit" style={{ width: '100%', background: '#0C447C', color: '#fff', border: 'none', borderRadius: 8, padding: 10, fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>Sign in →</button>
        </form>
        <div style={{ marginTop: 14, textAlign: 'center' }}>
          <a href="/advisor" style={{ fontSize: 12, color: '#888', textDecoration: 'none' }}>← Advisor dashboard</a>
        </div>
      </div>
    </div>
  )

  const F = (label: string, key: keyof Job, type = 'text', opts?: string[]) => (
    <div style={{ marginBottom: 12 }}>
      <label style={{ fontSize: 12, color: '#666', display: 'block', marginBottom: 4 }}>{label}</label>
      {opts ? (
        <select value={(form as any)[key] || ''} onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
          style={{ width: '100%', fontSize: 13, padding: '8px 10px', border: '1px solid #ccc', borderRadius: 6 }}>
          {opts.map(o => <option key={o} value={o}>{o}</option>)}
        </select>
      ) : (
        <input type={type} value={(form as any)[key] || ''}
          onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
          style={{ width: '100%', fontSize: 13, padding: '8px 10px', border: '1px solid #ccc', borderRadius: 6 }} />
      )}
    </div>
  )

  return (
    <div>
      <div style={{ background: '#0C447C', padding: '14px 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ color: '#fff', fontSize: 15, fontWeight: 600 }}>PBSC Career Services — Job Admin</div>
        <div style={{ display: 'flex', gap: 8 }}>
          <a href="/advisor" style={{ fontSize: 11, background: 'rgba(255,255,255,.18)', color: '#fff', padding: '3px 9px', borderRadius: 6, textDecoration: 'none' }}>Advisor dashboard</a>
          <a href="/student" style={{ fontSize: 11, background: 'rgba(255,255,255,.18)', color: '#fff', padding: '3px 9px', borderRadius: 6, textDecoration: 'none' }}>Student board</a>
        </div>
      </div>

      <div style={{ padding: 24, maxWidth: 900, margin: '0 auto', display: 'grid', gridTemplateColumns: '340px 1fr', gap: 24, alignItems: 'flex-start' }}>

        {/* Add job form */}
        <div style={{ background: '#fff', border: '1px solid #e0e0e0', borderRadius: 10, padding: 20 }}>
          <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 16 }}>Add new listing</div>
          <form onSubmit={addJob}>
            {F('Job title *', 'title')}
            {F('Employer *', 'employer')}
            {F('Employer email', 'employer_email', 'email')}
            {F('Apply URL *', 'apply_url', 'url')}
            {F('Skills / notes', 'skills')}
            {F('Category', 'category', 'text', ['IT','Business','Data','Finance'])}
            {F('Level', 'level', 'text', ['Entry','Mid','Intern'])}
            {F('Source', 'source', 'text', ['I','B','P','B+P'])}
            {F('Fit', 'fit', 'text', ['Strong','Partial','Foundational'])}

            <div style={{ marginBottom: 16 }}>
              <label style={{ fontSize: 12, color: '#666', display: 'block', marginBottom: 6 }}>Programs (select all that apply)</label>
              {PROGRAMS.map(p => (
                <label key={p.value} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, marginBottom: 4, cursor: 'pointer' }}>
                  <input type="checkbox" checked={form.programs?.includes(p.value) || false}
                    onChange={e => setForm(f => ({
                      ...f,
                      programs: e.target.checked
                        ? [...(f.programs||[]), p.value]
                        : (f.programs||[]).filter((x:string) => x !== p.value)
                    }))} />
                  {p.label}
                </label>
              ))}
            </div>

            {error && <div style={{ color: '#A32D2D', fontSize: 12, marginBottom: 10 }}>{error}</div>}
            {saved && <div style={{ color: '#27500A', fontSize: 12, marginBottom: 10 }}>✓ Listing added successfully</div>}

            <button type="submit" disabled={saving}
              style={{ width: '100%', background: saving ? '#ccc' : '#0C447C', color: '#fff', border: 'none', borderRadius: 8, padding: 10, fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>
              {saving ? 'Saving...' : 'Add listing'}
            </button>
          </form>
        </div>

        {/* Active listings */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
            <div style={{ fontSize: 15, fontWeight: 600 }}>Active listings ({jobs.length})</div>
            <button onClick={() => loadJobs(password)} style={{ fontSize: 12, color: '#888', background: 'none', border: '1px solid #ccc', borderRadius: 6, padding: '5px 10px', cursor: 'pointer' }}>↻ Refresh</button>
          </div>

          {loading && <div style={{ textAlign: 'center', padding: 40, color: '#888' }}>Loading...</div>}

          {jobs.map(j => (
            <div key={j.id} style={{ background: '#fff', border: '1px solid #e0e0e0', borderRadius: 8, padding: '12px 14px', marginBottom: 8, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <div style={{ fontSize: 13, fontWeight: 600 }}>{j.title}</div>
                <div style={{ fontSize: 12, color: '#666' }}>{j.employer}</div>
                <div style={{ fontSize: 11, color: '#aaa', marginTop: 4 }}>{j.level} · {j.category} · {j.fit} fit</div>
              </div>
              <div style={{ display: 'flex', gap: 6, alignItems: 'center', flexShrink: 0 }}>
                <span style={{ fontSize: 10, background: j.is_active ? '#E1F5EE' : '#F1EFE8', color: j.is_active ? '#085041' : '#888', padding: '2px 6px', borderRadius: 4, fontWeight: 600 }}>
                  {j.is_active ? 'Active' : 'Inactive'}
                </span>
                <a href={j.apply_url} target="_blank" rel="noopener noreferrer"
                  style={{ fontSize: 11, color: '#0C447C', textDecoration: 'none' }}>View →</a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
