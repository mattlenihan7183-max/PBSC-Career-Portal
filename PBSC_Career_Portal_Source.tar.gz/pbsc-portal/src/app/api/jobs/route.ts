import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const level    = searchParams.get('level')
  const category = searchParams.get('category')
  const program  = searchParams.get('program')
  const search   = searchParams.get('search')

  let query = supabaseAdmin
    .from('jobs')
    .select('*')
    .eq('is_active', true)
    .order('level', { ascending: true })
    .order('title', { ascending: true })

  if (level)    query = query.eq('level', level)
  if (category) query = query.eq('category', category)
  if (program)  query = query.contains('programs', [program])
  if (search)   query = query.or(`title.ilike.%${search}%,employer.ilike.%${search}%`)

  const { data, error } = await query
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ jobs: data })
}

export async function POST(req: NextRequest) {
  // Admin only — check password header
  const auth = req.headers.get('x-admin-password')
  if (auth !== process.env.ADMIN_PASSWORD) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }
  const body = await req.json()
  const { data, error } = await supabaseAdmin
    .from('jobs')
    .insert([body])
    .select()
    .single()
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ job: data })
}
