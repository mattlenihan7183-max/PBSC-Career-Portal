import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const { searchParams } = new URL(req.url)
  const response = searchParams.get('r')

  const validOutcomes = ['heard_back','interview','offer','no_response','withdrew']
  if (!response || !validOutcomes.includes(response)) {
    return NextResponse.redirect(`${process.env.NEXT_PUBLIC_APP_URL}/followup/invalid`)
  }

  await supabaseAdmin
    .from('applications')
    .update({ outcome: response, outcome_at: new Date().toISOString() })
    .eq('id', params.id)

  await supabaseAdmin
    .from('followup_log')
    .update({ responded_at: new Date().toISOString(), response })
    .eq('application_id', params.id)
    .is('responded_at', null)

  return NextResponse.redirect(
    `${process.env.NEXT_PUBLIC_APP_URL}/followup/${params.id}/thanks?r=${response}`
  )
}
