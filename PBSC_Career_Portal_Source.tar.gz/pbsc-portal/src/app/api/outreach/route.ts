import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { sendEmployerIntroduction } from '@/lib/email'

export async function POST(req: NextRequest) {
  const auth = req.headers.get('x-advisor-password')
  if (auth !== process.env.ADVISOR_PASSWORD) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { applicationId, employerEmail, employerName, studentName,
          program, graduation, jobTitle, customBody, sentBy } = await req.json()

  const result = await sendEmployerIntroduction({
    employerEmail, employerName, studentName, program, graduation, jobTitle, customBody
  })

  if (result.success) {
    await supabaseAdmin.from('outreach_log').insert([{
      application_id: applicationId,
      employer_email: employerEmail,
      email_body:     customBody,
      sent_by:        sentBy || 'Career Services',
    }])
  }

  return NextResponse.json(result)
}
