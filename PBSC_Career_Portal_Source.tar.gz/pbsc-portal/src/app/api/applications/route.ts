import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import {
  sendAdvisorNotification,
  sendStudentConfirmation,
} from '@/lib/email'

export async function POST(req: NextRequest) {
  const body = await req.json()
  const { name, studentId, email, program, graduation, jobId } = body

  if (!name || !studentId || !program || !graduation || !jobId) {
    return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
  }

  // 1. Upsert student record
  const { data: student, error: sErr } = await supabaseAdmin
    .from('students')
    .upsert({ name, student_id: studentId, email: email || null, program, graduation },
             { onConflict: 'student_id' })
    .select()
    .single()

  if (sErr) return NextResponse.json({ error: sErr.message }, { status: 500 })

  // 2. Fetch job details
  const { data: job, error: jErr } = await supabaseAdmin
    .from('jobs')
    .select('*')
    .eq('id', jobId)
    .single()

  if (jErr || !job) return NextResponse.json({ error: 'Job not found' }, { status: 404 })

  // 3. Create application (ignore duplicate)
  const { data: app, error: aErr } = await supabaseAdmin
    .from('applications')
    .upsert({ student_id: student.id, job_id: job.id },
             { onConflict: 'student_id,job_id', ignoreDuplicates: false })
    .select()
    .single()

  if (aErr) return NextResponse.json({ error: aErr.message }, { status: 500 })

  // 4. Fire emails (non-blocking — don't fail the request if email fails)
  const emailData = {
    studentName:   name,
    studentId,
    studentEmail:  email || '',
    program,
    graduation,
    jobTitle:      job.title,
    employer:      job.employer,
    fit:           job.fit,
    level:         job.level,
    source:        job.source,
    applyUrl:      job.apply_url,
    applicationId: app.id,
  }

  Promise.all([
    sendAdvisorNotification(emailData),
    sendStudentConfirmation({ studentName: name, studentEmail: email || '', jobTitle: job.title, employer: job.employer }),
  ]).then(([advisorResult]) => {
    if (advisorResult.success) {
      supabaseAdmin.from('applications')
        .update({ advisor_notified: true })
        .eq('id', app.id)
        .then(() => {})
    }
  })

  return NextResponse.json({
    success: true,
    applicationId: app.id,
    job: { title: job.title, employer: job.employer },
  })
}

export async function GET(req: NextRequest) {
  // Advisor only
  const auth = req.headers.get('x-advisor-password')
  if (auth !== process.env.ADVISOR_PASSWORD) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { data, error } = await supabaseAdmin
    .from('applications_full')
    .select('*')
    .order('applied_at', { ascending: false })
    .limit(200)

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ applications: data })
}
