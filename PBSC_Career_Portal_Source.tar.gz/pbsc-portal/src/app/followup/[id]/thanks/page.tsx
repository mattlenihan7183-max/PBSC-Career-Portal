import { redirect } from 'next/navigation'

const MESSAGES: Record<string, { title: string; body: string }> = {
  heard_back:  { title: "Great — glad you heard back!",    body: "Your advisor has been updated. They may reach out to help you prepare for next steps." },
  interview:   { title: "Congratulations on the interview!", body: "This is excellent news. Your advisor has been notified and can help you prepare. Good luck!" },
  offer:       { title: "You got an offer — amazing!",      body: "Please let your advisor know so we can record this placement. This helps PBSC support future students." },
  no_response: { title: "Thanks for letting us know",       body: "We've noted this. Your advisor may reach out about other opportunities that match your profile." },
  withdrew:    { title: "Understood — thanks for updating", body: "We've noted your withdrawal from this application." },
}

export default function FollowupThanks({
  params, searchParams
}: {
  params: { id: string }
  searchParams: { r?: string }
}) {
  const r = searchParams.r || 'no_response'
  const msg = MESSAGES[r] || MESSAGES.no_response

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16, background: '#f5f5f3', fontFamily: 'Arial, sans-serif' }}>
      <div style={{ background: '#fff', borderRadius: 12, border: '1px solid #e0e0e0', padding: 32, width: '100%', maxWidth: 420, textAlign: 'center' }}>
        <div style={{ width: 48, height: 48, borderRadius: '50%', background: r === 'interview' || r === 'offer' ? '#1D9E75' : '#0C447C', margin: '0 auto 16px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="20 6 9 17 4 12"/>
          </svg>
        </div>
        <div style={{ fontSize: 17, fontWeight: 600, marginBottom: 8 }}>{msg.title}</div>
        <div style={{ fontSize: 13, color: '#666', lineHeight: 1.7, marginBottom: 24 }}>{msg.body}</div>
        <a href="/student" style={{ display: 'inline-block', background: '#0C447C', color: '#fff', padding: '10px 20px', borderRadius: 8, fontSize: 13, fontWeight: 600, textDecoration: 'none' }}>
          Browse more jobs →
        </a>
        <div style={{ marginTop: 20, fontSize: 11, color: '#aaa' }}>
          PBSC Career Services · careers@palmbeachstate.edu · (561) 868-3000
        </div>
      </div>
    </div>
  )
}
