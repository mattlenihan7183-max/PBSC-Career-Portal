import type { Metadata } from 'next'
export const metadata: Metadata = {
  title: 'PBSC Career Services Portal',
  description: 'Palm Beach State College — student job board, advisor dashboard, employer outreach',
}
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <style>{`
          *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
          body { font-family: Arial, Helvetica, sans-serif; background: #f5f5f3; color: #1a1a1a; min-height: 100vh; }
          input, select, textarea, button { font-family: inherit; }
          a { color: inherit; }
          .sr-only { position:absolute; width:1px; height:1px; overflow:hidden; clip:rect(0,0,0,0); }
        `}</style>
      </head>
      <body>{children}</body>
    </html>
  )
}
