export interface Job {
  id:             string
  title:          string
  employer:       string
  employer_email: string
  category:       string
  level:          'Entry' | 'Mid' | 'Intern'
  source:         string
  apply_url:      string
  fit:            'Strong' | 'Partial' | 'Foundational'
  skills:         string
  programs:       string[]
  is_active:      boolean
  created_at:     string
  updated_at:     string
}

export interface Student {
  id:          string
  name:        string
  student_id:  string
  email:       string
  program:     string
  graduation:  string
  created_at:  string
}

export interface Application {
  id:                 string
  student_id:         string
  job_id:             string
  applied_at:         string
  advisor_notified:   boolean
  resume_sent:        boolean
  checkin_scheduled:  boolean
  followup_flagged:   boolean
  outcome:            string | null
  outcome_at:         string | null
  notes:              string | null
}

export interface ApplicationFull extends Application {
  student_name:     string
  student_pbsc_id:  string
  student_email:    string
  student_program:  string
  student_graduation: string
  job_title:        string
  job_employer:     string
  employer_email:   string
  job_category:     string
  job_level:        string
  job_fit:          string
  job_source:       string
  job_apply_url:    string
}

export interface OutreachLog {
  id:             string
  application_id: string
  employer_email: string
  email_body:     string
  sent_at:        string
  sent_by:        string
}

export const PROGRAMS = [
  { value: 'AS-BusAdmin',   label: 'AS: Business Admin & Management' },
  { value: 'AS-BusEntrep',  label: 'AS: Business Entrepreneurship' },
  { value: 'AS-CompProg',   label: 'AS: Computer Programming' },
  { value: 'AS-NetAdmin',   label: 'AS: Network Administration' },
  { value: 'BAS-DB',        label: 'BAS: Info Mgmt – DB/Analytics' },
  { value: 'BAS-ProjMgmt',  label: 'BAS: Info Mgmt – Project Mgmt' },
  { value: 'BAS-Security',  label: 'BAS: Info Mgmt – Security/Network' },
  { value: 'BAS-SupMgmt',   label: 'BAS: Supervision & Management' },
]

export const GRADUATIONS = [
  'Spring 2026','Fall 2026','Spring 2027','Fall 2027','Spring 2028'
]

export const FIT_COLORS: Record<string, string> = {
  Strong:      '#E1F5EE',
  Partial:     '#FAEEDA',
  Foundational:'#F1EFE8',
}
export const FIT_TEXT: Record<string, string> = {
  Strong:      '#085041',
  Partial:     '#633806',
  Foundational:'#444441',
}
export const LEVEL_COLORS: Record<string, string> = {
  Entry:  '#FFF0C0',
  Mid:    '#E6F1FB',
  Intern: '#E1F5EE',
}
export const LEVEL_TEXT: Record<string, string> = {
  Entry:  '#7A5800',
  Mid:    '#0C447C',
  Intern: '#085041',
}
