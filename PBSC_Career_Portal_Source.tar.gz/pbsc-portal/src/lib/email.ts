import sgMail from '@sendgrid/mail'

if (process.env.SENDGRID_API_KEY) {
  sgMail.setApiKey(process.env.SENDGRID_API_KEY)
}

const FROM = {
  email: process.env.CAREER_SERVICES_EMAIL || 'careers@palmbeachstate.edu',
  name:  process.env.CAREER_SERVICES_NAME  || 'PBSC Career Services',
}
const PHONE = process.env.CAREER_SERVICES_PHONE || '(561) 868-3000'
const SEND  = process.env.SEND_REAL_EMAILS === 'true'

async function send(to: string, subject: string, html: string, text: string) {
  if (!SEND) {
    console.log(`\n📧 [EMAIL — not sent, set SEND_REAL_EMAILS=true]\nTo: ${to}\nSubject: ${subject}\n---\n${text}\n`)
    return { success: true, simulated: true }
  }
  try {
    await sgMail.send({ to, from: FROM, subject, html, text })
    return { success: true }
  } catch (err: any) {
    console.error('SendGrid error:', err?.response?.body || err)
    return { success: false, error: err?.message }
  }
}

// ── 1. Advisor notification ───────────────────────────────────────────────
export async function sendAdvisorNotification(data: {
  studentName: string
  studentId:   string
  studentEmail:string
  program:     string
  graduation:  string
  jobTitle:    string
  employer:    string
  fit:         string
  level:       string
  source:      string
  applyUrl:    string
  applicationId: string
}) {
  const advisorEmail = FROM.email
  const subject = `New application — ${data.studentName} → ${data.jobTitle}`
  const text = `
New application logged — PBSC Career Services

Student:     ${data.studentName}
PBSC ID:     ${data.studentId}
Email:       ${data.studentEmail}
Program:     ${data.program}
Graduating:  ${data.graduation}

Applied to:  ${data.jobTitle}
Employer:    ${data.employer}
Alignment:   ${data.fit} fit
Level:       ${data.level}
Source:      ${data.source}

Suggested actions:
→ Send ${data.studentName.split(' ')[0]} resume review resources
→ Schedule a 15-min advising check-in
→ Flag for 2-week outcome follow-up

View full dashboard: ${process.env.NEXT_PUBLIC_APP_URL}/advisor
`.trim()

  const html = `
<div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto">
  <div style="background:#0C447C;padding:16px 20px;border-radius:8px 8px 0 0">
    <p style="color:#fff;font-size:15px;font-weight:600;margin:0">New application — PBSC Career Services</p>
  </div>
  <div style="border:1px solid #e0e0e0;border-top:none;border-radius:0 0 8px 8px;padding:20px">
    <div style="background:#E6F1FB;border-radius:6px;padding:12px 14px;margin-bottom:16px">
      <p style="font-size:11px;color:#0C447C;font-weight:600;margin:0 0 4px">Applied to</p>
      <p style="font-size:15px;font-weight:600;color:#1a1a1a;margin:0">${data.jobTitle}</p>
      <p style="font-size:12px;color:#555;margin:2px 0 0">${data.employer}</p>
    </div>
    <table style="width:100%;font-size:13px;border-collapse:collapse">
      <tr><td style="color:#888;padding:5px 0;width:130px">Student</td><td style="color:#1a1a1a;font-weight:600">${data.studentName}</td></tr>
      <tr><td style="color:#888;padding:5px 0">PBSC ID</td><td style="color:#1a1a1a">${data.studentId}</td></tr>
      <tr><td style="color:#888;padding:5px 0">Program</td><td style="color:#1a1a1a">${data.program}</td></tr>
      <tr><td style="color:#888;padding:5px 0">Graduating</td><td style="color:#1a1a1a">${data.graduation}</td></tr>
      <tr><td style="color:#888;padding:5px 0">Alignment</td><td><span style="background:#E1F5EE;color:#085041;font-size:11px;font-weight:600;padding:2px 8px;border-radius:4px">${data.fit} fit</span></td></tr>
    </table>
    <div style="border-top:1px solid #eee;margin:16px 0;padding-top:14px">
      <p style="font-size:12px;color:#888;font-weight:600;margin:0 0 8px">Suggested actions</p>
      <p style="font-size:13px;color:#333;margin:4px 0">→ Send ${data.studentName.split(' ')[0]} resume review resources</p>
      <p style="font-size:13px;color:#333;margin:4px 0">→ Schedule a 15-min advising check-in</p>
      <p style="font-size:13px;color:#333;margin:4px 0">→ Flag for 2-week outcome follow-up</p>
    </div>
    <a href="${process.env.NEXT_PUBLIC_APP_URL}/advisor" style="display:inline-block;background:#0C447C;color:#fff;font-size:13px;font-weight:600;padding:10px 18px;border-radius:6px;text-decoration:none">View advisor dashboard →</a>
    <p style="font-size:11px;color:#aaa;margin-top:16px">PBSC Career Services · ${FROM.email} · ${PHONE}</p>
  </div>
</div>`
  return send(advisorEmail, subject, html, text)
}

// ── 2. Student confirmation ───────────────────────────────────────────────
export async function sendStudentConfirmation(data: {
  studentName: string
  studentEmail:string
  jobTitle:    string
  employer:    string
}) {
  if (!data.studentEmail) return { success: true, skipped: true }
  const first = data.studentName.split(' ')[0]
  const subject = `We got your application — ${data.jobTitle}`
  const text = `
Hi ${first},

Your PBSC Career Services application tracker has logged your interest in:
${data.jobTitle} at ${data.employer}

Your advisor has been notified and may reach out with resume tips or interview prep resources. In two weeks, you'll receive a short follow-up asking if you heard back.

Good luck!
PBSC Career Services
${FROM.email} | ${PHONE}
`.trim()

  const html = `
<div style="font-family:Arial,sans-serif;max-width:520px;margin:0 auto">
  <div style="background:#0C447C;padding:16px 20px;border-radius:8px 8px 0 0">
    <p style="color:#fff;font-size:15px;font-weight:600;margin:0">You're on your way, ${first}!</p>
  </div>
  <div style="border:1px solid #e0e0e0;border-top:none;border-radius:0 0 8px 8px;padding:20px">
    <div style="background:#E1F5EE;border-radius:6px;padding:12px 14px;margin-bottom:16px">
      <p style="font-size:11px;color:#085041;font-weight:600;margin:0 0 3px">Application tracked</p>
      <p style="font-size:15px;font-weight:600;color:#1a1a1a;margin:0">${data.jobTitle}</p>
      <p style="font-size:12px;color:#555;margin:2px 0 0">${data.employer}</p>
    </div>
    <p style="font-size:13px;color:#555;line-height:1.7">Your advisor has been notified and may reach out with resume tips or interview prep. In two weeks you'll receive a short follow-up asking if you heard back.</p>
    <p style="font-size:11px;color:#aaa;margin-top:20px">PBSC Career Services · ${FROM.email} · ${PHONE}</p>
  </div>
</div>`
  return send(data.studentEmail, subject, html, text)
}

// ── 3. Employer warm introduction ─────────────────────────────────────────
export async function sendEmployerIntroduction(data: {
  employerEmail: string
  employerName:  string
  studentName:   string
  program:       string
  graduation:    string
  jobTitle:      string
  customBody:    string
}) {
  const subject = `PBSC Student Application — ${data.studentName} for ${data.jobTitle}`
  return send(data.employerEmail, subject, `<pre style="font-family:Arial;font-size:13px;white-space:pre-wrap">${data.customBody}</pre>`, data.customBody)
}

// ── 4. Two-week follow-up ─────────────────────────────────────────────────
export async function sendFollowUpEmail(data: {
  studentEmail:    string
  studentName:     string
  jobTitle:        string
  employer:        string
  applicationId:   string
}) {
  if (!data.studentEmail) return { success: true, skipped: true }
  const first = data.studentName.split(' ')[0]
  const base  = process.env.NEXT_PUBLIC_APP_URL
  const subject = `Quick check-in — ${data.jobTitle} at ${data.employer}`
  const text = `
Hi ${first},

Two weeks ago you applied for ${data.jobTitle} at ${data.employer} through PBSC Career Services.

Did you hear back? Let us know so we can support you:

→ Yes, I heard back: ${base}/followup/${data.applicationId}?r=heard_back
→ I got an interview: ${base}/followup/${data.applicationId}?r=interview
→ No response yet:   ${base}/followup/${data.applicationId}?r=no_response

Your feedback helps us improve outcomes for all PBSC students.

PBSC Career Services
${FROM.email} | ${PHONE}
`.trim()

  const html = `
<div style="font-family:Arial,sans-serif;max-width:520px;margin:0 auto">
  <div style="background:#0C447C;padding:16px 20px;border-radius:8px 8px 0 0">
    <p style="color:#fff;font-size:15px;font-weight:600;margin:0">Quick check-in, ${first}</p>
  </div>
  <div style="border:1px solid #e0e0e0;border-top:none;border-radius:0 0 8px 8px;padding:20px">
    <p style="font-size:13px;color:#555;margin-bottom:16px">Two weeks ago you applied for <strong>${data.jobTitle}</strong> at <strong>${data.employer}</strong>. Did you hear back?</p>
    <div style="display:flex;flex-direction:column;gap:8px">
      <a href="${base}/followup/${data.applicationId}?r=heard_back" style="display:block;background:#E6F1FB;color:#0C447C;font-size:13px;font-weight:600;padding:10px 14px;border-radius:6px;text-decoration:none">Yes, I heard back →</a>
      <a href="${base}/followup/${data.applicationId}?r=interview"  style="display:block;background:#E1F5EE;color:#085041;font-size:13px;font-weight:600;padding:10px 14px;border-radius:6px;text-decoration:none">I got an interview →</a>
      <a href="${base}/followup/${data.applicationId}?r=no_response" style="display:block;background:#F1EFE8;color:#444;font-size:13px;font-weight:600;padding:10px 14px;border-radius:6px;text-decoration:none">No response yet →</a>
    </div>
    <p style="font-size:11px;color:#aaa;margin-top:20px">PBSC Career Services · ${FROM.email} · ${PHONE}</p>
  </div>
</div>`
  return send(data.studentEmail, subject, html, text)
}
