# PBSC Career Services Portal

Full-stack web application — student job board, real-time advisor dashboard, employer outreach, and application outcome tracking.

## Tech stack

| Layer      | Tool                  |
|------------|-----------------------|
| Framework  | Next.js 14 (App Router) |
| Database   | Supabase (Postgres)   |
| Email      | SendGrid              |
| Hosting    | Vercel (recommended)  |
| Language   | TypeScript            |

---

## Setup — step by step

### 1. Supabase

1. Go to [supabase.com](https://supabase.com) → New project
2. Open the SQL editor → paste the contents of `supabase/migrations/001_schema.sql` → Run
3. Copy your **Project URL**, **anon key**, and **service role key** from Settings → API

### 2. SendGrid

1. Create a free account at [sendgrid.com](https://sendgrid.com)
2. Verify a sender email (e.g. `careers@palmbeachstate.edu`) under Settings → Sender Authentication
3. Create an API key under Settings → API Keys → Full Access

### 3. Environment variables

Copy `.env.local.example` to `.env.local` and fill in:

```bash
cp .env.local.example .env.local
```

Then edit `.env.local`:

```env
NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
SUPABASE_SERVICE_ROLE_KEY=eyJ...
SENDGRID_API_KEY=SG.xxx
CAREER_SERVICES_EMAIL=careers@palmbeachstate.edu
CAREER_SERVICES_NAME=PBSC Career Services
CAREER_SERVICES_PHONE=(561) 868-3000
NEXT_PUBLIC_APP_URL=https://careers.palmbeachstate.edu
ADVISOR_PASSWORD=choose-a-strong-password
ADMIN_PASSWORD=choose-a-different-strong-password
SEND_REAL_EMAILS=false   # change to true when ready
```

### 4. Run locally

```bash
npm install
npm run dev
```

Visit:
- `http://localhost:3000/student`  — student job board
- `http://localhost:3000/advisor`  — advisor dashboard (password required)
- `http://localhost:3000/admin`    — job management (password required)

### 5. Deploy to Vercel

```bash
npm install -g vercel
vercel
```

Or connect your GitHub repo at [vercel.com](https://vercel.com) and add the environment variables in the Vercel dashboard under Settings → Environment Variables.

---

## Application flow

```
Student clicks a job → Apply modal → Submits form
          │
          ├─→ Row written to Supabase (students + applications tables)
          ├─→ Advisor notification email fired (SendGrid)
          ├─→ Student confirmation email fired (SendGrid)
          └─→ Redirect to actual job listing

Advisor logs in → Sees all applications in real time
          │
          ├─→ Marks actions (resume sent, check-in, follow-up flag)
          └─→ Composes & sends employer introduction email

14 days later → Supabase scheduled function fires follow-up email
          │
          └─→ Student clicks outcome link → outcome written to DB
```

---

## Pages

| URL             | Who      | What                                          |
|-----------------|----------|-----------------------------------------------|
| `/student`      | Students | Job board with filters, apply modal           |
| `/advisor`      | Advisors | Real-time notifications, action checklist, employer outreach |
| `/admin`        | Staff    | Add/edit/deactivate job listings              |
| `/followup/:id/thanks` | Students | Outcome confirmation after clicking follow-up email link |

---

## API routes

| Method | Endpoint                  | Auth             | Description                    |
|--------|---------------------------|------------------|--------------------------------|
| GET    | `/api/jobs`               | None             | Fetch active jobs (with filters) |
| POST   | `/api/jobs`               | Admin password   | Add a new job listing          |
| POST   | `/api/applications`       | None             | Submit an application          |
| GET    | `/api/applications`       | Advisor password | Fetch all applications         |
| PATCH  | `/api/applications/:id`   | Advisor password | Update advisor action flags    |
| POST   | `/api/outreach`           | Advisor password | Send employer introduction email |
| GET    | `/api/auth/followup/:id`  | None (link-based)| Record student outcome response |

---

## Two-week follow-up automation

Supabase doesn't have native cron jobs, but you can trigger the follow-up emails via:

**Option A — Supabase Edge Function + pg_cron:**
```sql
-- Run daily at 9am ET
SELECT cron.schedule('send-followups', '0 13 * * *', $$
  SELECT net.http_post(
    url := 'https://your-app.vercel.app/api/followup/send',
    headers := '{"x-cron-secret": "your-secret"}'::jsonb
  )
$$);
```

**Option B — Vercel Cron:**
Add to `vercel.json`:
```json
{
  "crons": [{ "path": "/api/followup/send", "schedule": "0 13 * * *" }]
}
```

---

## Adding/updating jobs

Log in to `/admin` with the admin password. Jobs added here appear on the student board immediately. To bulk-update, edit the seed data in `supabase/migrations/001_schema.sql` and re-run.

---

## FERPA note

Student data collected (name, student ID, email, program, graduation) is stored in your Supabase instance — not shared with any third party. The consent checkbox on the apply form documents student opt-in. Consult PBSC's FERPA officer before going live.

---

## Support

Built by PBSC Career Services initiative, April 2026.
For technical questions, contact PBSC IT or the developer of record.
