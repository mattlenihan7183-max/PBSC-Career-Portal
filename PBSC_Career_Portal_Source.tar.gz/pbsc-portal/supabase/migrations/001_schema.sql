-- ============================================================
-- PBSC Career Services Portal — Database Schema
-- Run this in your Supabase SQL editor or via the CLI
-- ============================================================

-- Enable UUID generation
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ── Jobs table ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS jobs (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title         TEXT NOT NULL,
  employer      TEXT NOT NULL,
  employer_email TEXT,
  category      TEXT NOT NULL,  -- 'IT', 'Business', 'Data', 'Finance'
  level         TEXT NOT NULL CHECK (level IN ('Entry', 'Mid', 'Intern')),
  source        TEXT NOT NULL,  -- 'I', 'B', 'P', 'B+P'
  apply_url     TEXT NOT NULL,
  fit           TEXT NOT NULL CHECK (fit IN ('Strong', 'Partial', 'Foundational')),
  skills        TEXT,
  programs      TEXT[] NOT NULL DEFAULT '{}',  -- array of program codes
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Students table ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS students (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name          TEXT NOT NULL,
  student_id    TEXT UNIQUE NOT NULL,
  email         TEXT,
  program       TEXT NOT NULL,
  graduation    TEXT NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Applications table ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS applications (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id      UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  job_id          UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  applied_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  -- Advisor tracking
  advisor_notified  BOOLEAN NOT NULL DEFAULT FALSE,
  resume_sent       BOOLEAN NOT NULL DEFAULT FALSE,
  checkin_scheduled BOOLEAN NOT NULL DEFAULT FALSE,
  followup_flagged  BOOLEAN NOT NULL DEFAULT FALSE,
  -- Outcome tracking (populated by 2-week follow-up)
  outcome         TEXT CHECK (outcome IN ('heard_back', 'interview', 'offer', 'no_response', 'withdrew', 'pending')),
  outcome_at      TIMESTAMPTZ,
  notes           TEXT
);

-- Prevent duplicate applications
CREATE UNIQUE INDEX IF NOT EXISTS applications_student_job_unique
  ON applications(student_id, job_id);

-- ── Outreach log ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS outreach_log (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  application_id  UUID NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
  employer_email  TEXT NOT NULL,
  email_body      TEXT NOT NULL,
  sent_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  sent_by         TEXT  -- advisor name/email
);

-- ── Follow-up log ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS followup_log (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  application_id  UUID NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
  sent_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  responded_at    TIMESTAMPTZ,
  response        TEXT
);

-- ── Updated_at trigger ────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER jobs_updated_at
  BEFORE UPDATE ON jobs
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ── Row Level Security ────────────────────────────────────────────────────
ALTER TABLE jobs        ENABLE ROW LEVEL SECURITY;
ALTER TABLE students    ENABLE ROW LEVEL SECURITY;
ALTER TABLE applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE outreach_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE followup_log ENABLE ROW LEVEL SECURITY;

-- Public can read active jobs
CREATE POLICY "jobs_public_read" ON jobs FOR SELECT USING (is_active = TRUE);

-- Service role has full access (used by API routes with service key)
CREATE POLICY "jobs_service_all"        ON jobs            FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "students_service_all"    ON students        FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "applications_service_all" ON applications   FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "outreach_service_all"    ON outreach_log    FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "followup_service_all"    ON followup_log    FOR ALL USING (auth.role() = 'service_role');

-- ── Seed jobs data ────────────────────────────────────────────────────────
INSERT INTO jobs (title, employer, employer_email, category, level, source, apply_url, fit, skills, programs) VALUES
('IT Help Desk Technician','QIT Solutions, West Palm Beach','hr@qitsolutions.com','IT','Entry','I','https://www.indeed.com/q-IT-Help-Desk-Technician-l-West-Palm-Beach,-FL-jobs.html','Strong','Windows, O365, troubleshooting, A+ preferred',ARRAY['AS-NetAdmin']),
('Jr. Systems Administrator','Town of Palm Beach','hr@townofpalmbeach.com','IT','Entry','I','https://www.indeed.com/q-Junior-Systems-Administrator-l-Palm-Beach,-FL-jobs.html','Strong','Active Directory, Windows/Linux, O365',ARRAY['AS-NetAdmin']),
('Help Desk Specialist','FAU College of Medicine, Boca Raton','it-hr@med.fau.edu','IT','Entry','I','https://www.indeed.com/q-Help-Desk-Specialist-l-Boca-Raton,-FL-jobs.html','Strong','Windows/Mac support, O365, JAMF, ticketing',ARRAY['AS-NetAdmin']),
('Jr. Cybersecurity Analyst','NSD Newco, Boca Raton','careers@nsdnewco.com','IT','Entry','I','https://www.indeed.com/q-Junior-Cybersecurity-Analyst-l-Boca-Raton,-FL-jobs.html','Strong','Security fundamentals, GRC, CompTIA Sec+ a plus',ARRAY['BAS-Security']),
('Jr. Data Analyst','Health Sciences employer, Jupiter','jobs@healthscijupiter.com','Data','Entry','I','https://www.indeed.com/q-Junior-Data-Analyst-l-Jupiter,-FL-jobs.html','Strong','Excel, SQL basics, data visualization',ARRAY['BAS-DB']),
('Jr. E-Commerce / Web Developer','Ideal Nutrition, West Palm Beach','hr@idealnutrition.com','IT','Entry','I','https://www.indeed.com/q-Junior-Web-Developer-l-West-Palm-Beach,-FL-jobs.html','Strong','HTML/CSS, JavaScript, Shopify/WordPress',ARRAY['AS-CompProg']),
('Associate Business Analyst','Vertical Bridge, West Palm Beach','hr@verticalbridge.com','Business','Entry','I','https://www.indeed.com/q-Associate-Business-Analyst-l-West-Palm-Beach,-FL-jobs.html','Partial','Excel, process mapping, requirements docs',ARRAY['AS-BusAdmin','BAS-DB']),
('Operations Assistant / Analyst','KioSoft Technologies, Palm Beach Gardens','jobs@kiosoft.com','Business','Entry','B','https://jobs.bdb.org/jobs','Partial','Operations support, Excel, data tracking',ARRAY['AS-BusAdmin']),
('IT Service Desk Analyst (L1)','Cross Country Healthcare, Boca Raton','itjobs@crosscountryhealthcare.com','IT','Entry','I','https://www.indeed.com/q-IT-Service-Desk-l-Boca-Raton,-FL-jobs.html','Strong','Tier 1 support, Windows, ticketing',ARRAY['AS-NetAdmin']),
('Business Analyst','Solid Waste Authority, West Palm Beach','hr@swa.org','Business','Mid','I','https://www.indeed.com/q-Business-Analyst-l-Palm-Beach-County,-FL-jobs.html','Strong','SQL, Agile/Jira, data analysis',ARRAY['BAS-DB','BAS-ProjMgmt']),
('Business Analyst II – Courts','Clerk of Circuit Court, PBC','hr@pbcclerk.com','Business','Mid','B','https://jobs.bdb.org/jobs','Strong','SQL, court ops, requirements analysis',ARRAY['BAS-DB','BAS-ProjMgmt']),
('Project Manager (IT)','ServiceNow, West Palm Beach','talent@servicenow.com','IT','Mid','I','https://www.indeed.com/q-IT-Project-Manager-l-West-Palm-Beach,-FL-jobs.html','Strong','CAPM/PMP, Agile, stakeholder management',ARRAY['BAS-ProjMgmt']),
('Project Manager – Govt/Infra','Town of Jupiter','hr@jupiter.fl.us','IT','Mid','B','https://jobs.bdb.org/companies/town-of-jupiter','Strong','Govt project delivery, scheduling, budgets',ARRAY['BAS-ProjMgmt']),
('IT Systems Administrator','Port of Palm Beach','jobs@portofpalmbeach.com','IT','Mid','I','https://www.indeed.com/q-IT-Systems-Administrator-l-Palm-Beach-County,-FL-jobs.html','Strong','Windows/Linux, LAN/WAN, Cisco, Meraki',ARRAY['AS-NetAdmin','BAS-Security']),
('Cybersecurity Engineer','LanTech, West Palm Beach','careers@lantech.com','IT','Mid','I','https://www.indeed.com/q-Cybersecurity-Engineer-l-West-Palm-Beach,-FL-jobs.html','Strong','Fortinet NSE 4+, CompTIA Sec+, cloud security',ARRAY['BAS-Security']),
('Network Security Analyst','City of Boca Raton','hr@myboca.us','IT','Mid','I','https://www.indeed.com/q-Network-Security-Analyst-l-Palm-Beach-County,-FL-jobs.html','Strong','IDS/IPS, SIEM, network protocols',ARRAY['AS-NetAdmin','BAS-Security']),
('Data Analyst','PBACO / Twin-Star Intl / Westinghouse','hr@pbaco.com','Data','Mid','I','https://www.indeed.com/q-Data-Analyst-l-Palm-Beach-County,-FL-jobs.html','Strong','Snowflake, Tableau/Power BI, SQL',ARRAY['BAS-DB']),
('Enterprise Data Analyst','NextEra Energy, Juno Beach','university.relations@nextera.com','Data','Mid','B','https://jobs.bdb.org/companies/nextera-energy','Strong','SAP BW, Power BI, data warehouse',ARRAY['BAS-DB']),
('Software Engineer (HealthIT)','Modernizing Medicine, Boca Raton','debbie.cortina@modmed.com','IT','Mid','B+P','https://modmed.wd501.myworkdayjobs.com/en-US/ModMed12','Strong','Java/.NET/Python, AWS, Agile Scrum',ARRAY['AS-CompProg','BAS-DB']),
('IT Manager / Supervisor','iTHINK Financial CU, Delray Beach','hr@ithinkfi.org','IT','Mid','I','https://www.indeed.com/q-IT-Manager-l-Palm-Beach-County,-FL-jobs.html','Strong','Supervisory exp, O365, security basics',ARRAY['BAS-SupMgmt']),
('Branch Operations Lead','JPMorganChase, Boynton Beach','campus.recruiting@jpmorgan.com','Finance','Mid','B','https://jobs.bdb.org/companies/jpmorganchase','Strong','Banking ops, compliance, team leadership',ARRAY['BAS-SupMgmt']),
('Intern – Software Engineering','Modernizing Medicine, Boca Raton','debbie.cortina@modmed.com','IT','Intern','P','https://modmed.wd501.myworkdayjobs.com/en-US/ModMed12/details/XMLNAME-2026-Summer-Software-Engineering-Internships_R3905','Strong','Java/.NET/Python, AWS, GPA 3.0+',ARRAY['AS-CompProg','BAS-DB']),
('Intern – IT Systems Audit/SOX','SBA Communications, Boca Raton','djobin@sbasite.com','IT','Intern','P','https://sbasite.wd5.myworkdayjobs.com/en-US/SBA_Communications_Careers/details/Summer-Internship-2026--IT-Systems-Audit---SOX-Compliance_JR102179','Strong','SOX ITGC, IT audit, GRC, Excel/SQL a plus',ARRAY['BAS-Security']),
('Intern – Network Ops Center','SBA Communications, Boca Raton','djobin@sbasite.com','IT','Intern','P','https://internpalmbeach.com/jobs/2026-summer-internship-network-operations-control-center/','Strong','Network monitoring, alarm logs, NOC operations',ARRAY['AS-NetAdmin']),
('Intern – Health Data Analyst','PBACO, Palm Springs','hr@pbaco.com','Data','Intern','P','https://internpalmbeach.com/jobs/summer-2026-internship-program/','Strong','Healthcare data, ACO analytics, $15-16/hr',ARRAY['BAS-DB']),
('Intern – Event Mgmt/Ops','PBC Sports Commission, West Palm Beach','internships@pbcsports.com','Business','Intern','P','https://internpalmbeach.com/jobs/event-management-operations-intern/','Partial','Event ops, logistics, hotel/vendor database',ARRAY['AS-BusAdmin']),
('Intern – PR & Social Media','3i Advertising/PR, West Palm Beach','info@3iadvertising.com','Business','Intern','P','https://internpalmbeach.com/jobs/public-relations-and-social-media-internship/','Partial','PR, social media campaigns, press releases',ARRAY['AS-BusAdmin']),
('Intern – Store Management','Macy''s, Wellington','students@macys.com','Business','Intern','P','https://internpalmbeach.com/jobs/macys-2026-summer-internship-store-management-wellington-fl/','Partial','Retail management, customer service, leadership',ARRAY['BAS-SupMgmt']),
('Intern – Project Mgmt (Paid)','Lake Worth employer','','Business','Intern','I','https://www.indeed.com/q-Project-Management-Intern-l-Palm-Beach-County,-FL-jobs.html','Strong','Project planning, Agile basics, paid',ARRAY['BAS-ProjMgmt']),
('Intern – Finance/Accounting','NextEra Energy, Juno Beach','university.relations@nextera.com','Finance','Intern','I','https://www.indeed.com/q-Finance-Intern-l-Juno-Beach,-FL-jobs.html','Partial','Financial reporting, Excel, variance analysis',ARRAY['AS-BusAdmin']),
('Intern – Wealth Mgmt','Goldman Sachs / Ameriprise, WPB & Boca','campus.recruiting@gs.com','Finance','Intern','I','https://www.indeed.com/q-Wealth-Management-Intern-l-West-Palm-Beach,-FL-jobs.html','Partial','Finance, portfolio support, rising juniors+',ARRAY['BAS-SupMgmt']),
('Intern – Financial Services','BNY Wealth, Palm Beach','campus@bny.com','Finance','Intern','I','https://www.indeed.com/q-Financial-Services-Intern-l-Palm-Beach,-FL-jobs.html','Partial','Finance, business tech, data analytics, 10 weeks',ARRAY['AS-BusAdmin'])
ON CONFLICT DO NOTHING;

-- ── Useful views ──────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW applications_full AS
SELECT
  a.id,
  a.applied_at,
  a.advisor_notified,
  a.resume_sent,
  a.checkin_scheduled,
  a.followup_flagged,
  a.outcome,
  a.notes,
  s.name        AS student_name,
  s.student_id  AS student_pbsc_id,
  s.email       AS student_email,
  s.program     AS student_program,
  s.graduation  AS student_graduation,
  j.title       AS job_title,
  j.employer    AS job_employer,
  j.employer_email AS employer_email,
  j.category    AS job_category,
  j.level       AS job_level,
  j.fit         AS job_fit,
  j.source      AS job_source,
  j.apply_url   AS job_apply_url
FROM applications a
JOIN students s ON a.student_id = s.id
JOIN jobs j ON a.job_id = j.id
ORDER BY a.applied_at DESC;
